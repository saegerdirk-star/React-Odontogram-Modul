# @cognovis/fhir-sdk

Profile-bound TypeScript SDK for the Cognovis FHIR Implementation Guides, backed
by Aidbox in ordinary application and adapter use.

Install it and read or write conformant resources with typed builders and a
profile-scoped client. Ordinary applications and adapters use the authenticated
Aidbox factory; Health Samurai remains an internal provider detail. The advanced
transport seam and package bootstrap continue to support standard FHIR servers
that have the release closure loaded.

- Licence: Apache-2.0
- Runtime dependencies are pinned exactly: `@cognovis/fhir-release@0.2.9`,
  `@cognovis/fhir-deidentification-sdk@0.13.0`, and the temporary
  `@cognovis/aidbox-client-upstream@0.0.0-alpha.7.cognovis.1` bridge. The bridge
  is built from Cognovis Aidbox client source commit `72a90f2` and is replaced
  by an exact official Health Samurai release when the upstream contribution
  ships.

## Install

The package and its Cognovis dependencies live in the Cognovis npm registry, so the
registry and a token must be configured before installing. The package ships no
`.npmrc`; put the token in your own:

```ini
# ~/.npmrc
@cognovis:registry=https://npm.cognovis.de
//npm.cognovis.de/:_authToken=<token>
```

```sh
bun add @cognovis/fhir-sdk
```

### Supported runtime

The package root and every public subpath load under plain Node ESM. The
ordinary Aidbox factory dynamically loads the temporary bridge, whose inherited
extensionless imports require Bun, tsx, or a bundler at the point that factory
is called. The exact `@cognovis/fhir-release` dependency carries the generated
profile modules used by the root and dental entry points.

## Quickstart

```ts
import { createAidboxFhirClient, defineProfile } from '@cognovis/fhir-sdk/client'
import { buildDentalCondition } from '@cognovis/fhir-sdk/dental'
import { DentalConditionDEProfile } from '@cognovis/fhir-release/de-cognovis-fhir-dental/de-cognovis-fhir-dental/profiles/Condition_DentalConditionDE.js'

const baseUrl = 'https://aidbox.example.com' // Aidbox root, not its /fhir path
const client = await createAidboxFhirClient({
  baseUrl,
  clientId,
  clientSecret,
  writeSource: 'urn:example:application',
})
const conditions = client.forProfile(defineProfile(DentalConditionDEProfile, 'Condition'))

const created = await conditions.createResource(
  buildDentalCondition({
    code: { system: 'http://fhir.de/CodeSystem/bfarm/icd-10-gm', code: 'K02.1' },
    subject: { reference: 'Patient/p-1' },
  })
)

const readBack = await conditions.read(created.toResource().id!)
```

A complete, runnable flow — bootstrap, write, read back — is
[`examples/odontogram-round-trip.ts`](examples/odontogram-round-trip.ts).

## The client

`@cognovis/fhir-sdk/client`

| Export | Purpose |
| --- | --- |
| `createAidboxFhirClient(config)` / `FhirClient` | Ordinary authenticated Aidbox-backed client. |
| `client.forProfile(descriptor)` | A `ResourceClient` for one release-owned profile; its resource type is bound once in `defineProfile`. |
| `client.forResourceType(resourceType)` | A heterogeneous `ResourceFamilyClient` that resolves each returned or prebuilt resource through its declared release-owned leaf profile. |
| `createFhirClient({ transport })` / `FhirTransport` | Advanced seam for tests, replay, and deliberately implemented alternate stores. |
| `createFetchTransport(options)` | Ready-made fetch transport. |
| `RequestOptions` | Per-request positive deadline (`timeoutMs`) and caller `AbortSignal`. |
| `JsonPatchOperation` / `JsonPatchOptions` | Closed RFC 6902 operation union and conditional request controls for profile-bound `patch`. |
| `client.metadata(options?)` | Typed FHIR-root `GET /metadata`; no arbitrary root request escape hatch. |
| `FhirHttpError` / `FhirProfileMismatchError` | Error types. |
| `FHIR_SDK_ERROR_CODES` | Stable error-code catalogue. |
| `extractNextPageUrl(bundle)` | Relative URL of a search bundle's `next` link. |

`ResourceClient` offers `read`, one-page `search`, `next`, `create`,
`createResource`, `update` and `delete`. `search` returns `{ items, included,
total, next }`; included resources require an explicitly declared descriptor and
continuations are opaque capabilities accepted only by their issuing client.

Use `forResourceType()` when a search can return several valid leaves of the
same FHIR resource type. Each result is `{ canonical, value }`; `canonical` is
the resolved release canonical for intentional narrowing. Resolution reads
only `meta.profile`, selects a declared most-derived profile from the pinned
release registry, and fails closed with `profile-missing`, `profile-unknown`,
`profile-unsupported`, or `profile-ambiguous`. It does not guess an R4 base
profile or apply application-specific dispatch. `forProfile()` remains the
right API when the caller deliberately requires one exact homogeneous profile.

The shipped registry is generated from the exact `@cognovis/fhir-release`
dependency. A reviewed generator-only override may supply different profile
definition bytes when the release manifest binds the package, closure version,
generator version, archive digest, and review reason. This affects generated
validators and registry metadata only; the installed release closure remains the
runtime dependency contract. Runtime-only ZTS terminology packages do not contain
generated profile validators and remain outside profile-definition archive
discovery.

A regenerated registry entry may record the exact `StructureDefinition.version` read
from its verified package archive. Its bare URL and `URL|version` then resolve
to one identity, including when both appear in `meta.profile`. Other versions
remain unknown. The SDK preserves declarations for the concrete validator;
it never strips a version suffix to make a resource pass. Package versions do
not substitute for definition versions. Registry generation follows each
selected validator's exact package dependency graph and rejects conflicting
profile provenance. A selected validator with a missing or type-mismatched
root definition or an unresolved ancestor stops generation with its canonical
and the unresolved identity. An unversioned ancestor matching conflicting
definitions is rejected; the generator does not guess a preferred version.
JSON archive members are classified by `resourceType`,
so support does not depend on a filename prefix.

For a feed containing generic resources alongside declared profiles, opt in each
generic resource type with its published R4 base descriptor:

```ts
import { defineProfile } from '@cognovis/fhir-sdk/client'
import { CompositionProfile } from '@cognovis/fhir-release/hl7-fhir-r4-core/hl7-fhir-r4-core/profiles/Composition.js'

const compositions = client.forResourceType('Composition', {
  genericReadProfiles: [defineProfile(CompositionProfile, 'Composition')],
})
const page = await compositions.search({ subject: 'Patient/patient-1', _count: '50' })
for (const item of page.items) {
  const resource = item.value.toResource()
}
```

This option applies only to `read`, one-page `search`, and explicit `next` calls.
An absent or empty `meta.profile`, or exactly the configured base canonical,
selects that descriptor. Other declarations still use strict concrete profile
resolution. Unknown declarations, base-plus-unknown declarations, sibling profiles,
malformed metadata, and invalid concrete-profile payloads never retry as generic.
Without this option, the existing required-declaration behavior is unchanged.

Each configured descriptor must have the matching
`http://hl7.org/fhir/StructureDefinition/<ResourceType>` canonical. Configure
included generic resource types separately in the same `genericReadProfiles`
array; configuring a primary type does not authorize generic includes of other
types. Continuations retain this configuration and remain bound to their issuing
client and FHIR origin. A search never follows its next link automatically.

Generic values expose `toResource()` over the raw result of the supplied base
adapter, preserving its fields and metadata. Its public type guarantees only the
verified literal `resourceType`; other fields are `unknown` until the caller
validates them. The literal base `canonical` distinguishes this value from known
concrete profile instances in a mixed result. Validation is exactly that adapter's
`from()` contract plus SDK resource-type and metadata checks. Some published base
adapters check only the resource type; this option does not add full R4 schema
validation. Declared profiles retain their concrete validators. Writes, batches,
transactions, and bulk submissions do not gain a generic fallback from this option.

The family client resolves its `read`, search matches, search includes, and
`next`-page results independently; `createResource` and `update` return the
same resolved shape. A resource declaring a leaf and one of its ancestors is
resolved to that leaf while its declared compatible ancestor remains in
`meta.profile`. Incomparable sibling leaves, an absent declaration, or a
foreign declaration outside that lineage fail instead of depending on profile
order. This also keeps catalog and rule `ChargeItemDefinition` resources
distinct without inspecting business fields.

Family `batch` and `transaction` resolve and validate descriptor-less `POST` and
`PUT` submissions before dispatch and descriptor-less `GET` results before
returning them. Entries with an explicit `descriptor` use the same descriptor
validation as the top-level `batch` and `transaction` methods.
Family `bulk.submit` does the same for every NDJSON row before the provider is
called. Thus prebuilt heterogeneous inputs retain their declared profiles and
receive the configured `meta.source`; do not replace this with an application-owned
canonical map. `DELETE` remains an id-only operation and has no authoring
profile to resolve.

The committed `RELEASE_PROFILE_REGISTRY` is generated from the installed
`@cognovis/fhir-release` closure. `bun run generate:release-profiles` verifies
each source FHIR package archive against the manifest SHA-256 and derives
lineage from its `StructureDefinition.baseDefinition`; `bun run
check:release-profiles` verifies the committed closure digest and validator
inventory without downloading archives.

- `read(id)` returns `null` — a "not found" is valid absence.
- `search(params)` throws a stable `FhirSdkError` — a 404 on a search endpoint
  is a transport failure, not an empty result. An empty result is HTTP 200 with
  an empty bundle.
- `delete(id)` returns normally — deletion is idempotent. The ordinary Aidbox
  factory also accepts successful empty HTTP 204 responses for profile and
  resource-family deletion; other HTTP failures retain their status.

`bulk`, typed `operations`, and intent-specific `bootstrap` are capability
groups on the same client. Store-side credentials and AccessPolicy remain
authoritative; there is no caller elevation flag.

`createAidboxFhirClient` rejects insecure HTTP through its authentication
provider by default. `allowInsecureRequests: true` is an explicit local/test-only
transport opt-in for an HTTP Aidbox instance such as `127.0.0.1`; it grants no
FHIR operation, resource, or administrative authorization. Production clients
must use HTTPS and leave this option unset.

### Root metadata and bounded requests

Applications can replace a root `fetch` probe, timeout-capable handwritten
transport, and application-owned profile dispatch with the public client
surface. Use only a named root operation plus `RequestOptions` on the operation
being bounded:

```ts
import {
  createAidboxFhirClient,
  type RequestOptions,
} from '@cognovis/fhir-sdk/client'

const controller = new AbortController()
const request: RequestOptions = { timeoutMs: 2_000, signal: controller.signal }
const client = await createAidboxFhirClient({ baseUrl, clientId, clientSecret })
const capability = await client.metadata(request) // exactly GET /metadata
const patient = await client.forProfile(patientDescriptor).read(patientId, request)

const coverages = client.forResourceType('Coverage')
const firstPage = await coverages.search({ _count: '50' }, request)
for (const resolved of firstPage.items) {
  // Narrow on resolved.canonical only where leaf-specific behavior is required.
  console.log(resolved.canonical, resolved.value)
}
const nextPage = firstPage.next ? await coverages.next(firstPage.next, request) : undefined
```

Resource-family reads normally require one most-derived release profile. For
resources that legitimately declare independent profiles, explicitly opt in:

```ts
const patients = client.forResourceType('Patient', { validateAllDeclaredProfiles: true })
const result = await patients.read(patientId, request)
if (result) {
  console.log(result.canonicals) // all validated declared release identities
  const resource = result.value.toResource() // complete resource, including meta.profile
}
```

This read mode validates every supported declared profile independently, including
explicitly declared ancestors, and fails on unknown declarations, unsupported exact
versions, wrong resource types, or any validation failure. Known lineage-only
ancestors remain permitted. `canonicals` preserves declared version aliases and
contains supported declarations in first-occurrence order. It provides no single
`canonical` discriminator or generated leaf-class narrowing. Each `toResource()`
returns an independent copy of the original validated resource. Search matches,
included resources and continuations use the same mode. When combined with
`genericReadProfiles`, valid undeclared/base-only resources return a singleton
base canonical set; unknown profiles never fall back to that base. The default
read result and all create, update, PATCH, batch, transaction and bulk validation
remain strict; the opt-in does not permit ambiguous writes. This also applies to
GET entries in batch and transaction requests: only point `read`, `search` and
`next` use the opted-in validated-set result.

Both modes require the pinned registry and its generated validator to accept each
exact version declaration. In release `0.2.9`, the KBV Patient registry declares
`1.8.0`, but the generated validator checks `1.9.0`: a version-only
`KBV_PR_Base_Patient|1.8.0` declaration therefore fails with `profile-validation`.
The SDK does not inject a bare canonical, rewrite aliases or bypass validation to
repair that upstream disagreement. A registry-known version is necessary, but
not sufficient, for successful validation.

The opt-in eagerly snapshots the raw resource before validating independent
copies, including generic base reads. Descriptor transformations do not replace
that raw result. Non-cloneable raw input fails during the read with
`FhirSdkError` code `profile-validation` and the original cloning error as `cause`;
it does not defer a raw cloning exception until `toResource()`.

Profile-bound partial writes use RFC 6902 JSON Patch:

```ts
const updated = await client.forProfile(taskDescriptor).patch(taskId, [
  { op: 'test', path: '/status', value: 'requested' },
  { op: 'replace', path: '/status', value: 'in-progress' },
], { ifMatch: 'W/"4"', timeoutMs: 2_000, signal: controller.signal })
```

`patch` sends exactly one `PATCH` to the bound resource type and validated ID
with `application/json-patch+json`. It preserves operation order, JSON Pointer
escapes, null and false values, and the supplied `If-Match`. It supports `add`,
`remove`, `replace`, `move`, `copy` and `test`; extra operation members, malformed
pointers and non-JSON values fail before dispatch. The SDK does not inject a
`meta.source` patch, perform a preceding read or replace the mutation with PUT.
Successful resource responses pass through the selected profile validator;
204 and empty successful responses return `undefined`. HTTP failures preserve
their status and OperationOutcome on `FhirSdkError`, without mutation retries or
credential fallback. For an optimistic concurrency conflict, check
`error.status === 412`; the general `error.code` is `'transport'` and does not
distinguish this status from other HTTP failures. HTTP-derived `FhirSdkError`
instances now retain `status` for all resource-client operations, including
existing reads and writes.

For a heterogeneous family, pass the existing resource you already read:

```ts
const tasks = client.forResourceType('Task')
const existing = await tasks.read(taskId)
if (!existing) throw new Error('Task is missing')
const updated = await tasks.patch(existing.value.toResource(), [
  { op: 'replace', path: '/status', value: 'in-progress' },
], { ifMatch: 'W/"4"', signal: controller.signal })
if (updated) console.log(updated.canonical, updated.value.toResource().id)
```

`forResourceType().patch(existingResource, operations, options)` derives the ID
and exact release profile from that context before dispatch. It snapshots the
context, operations and request options before asynchronous profile loading.
The context must have a matching resource type, valid ID and one unambiguous
release-owned leaf declaration; the declared profile validates both context
and response. The result is a canonical-discriminated release value or
`undefined` for an empty success. This method performs no additional read.
An unknown declaration fails before dispatch. `genericReadProfiles` remains a
read-only option: unprofiled resources require an explicit `forProfile(base)`
write contract. Pass an `If-Match` from the same observed resource version when
concurrent changes must be rejected; the context alone does not impose one.

JSON Patch is rejected before dispatch inside deidentified
target-store scopes because arbitrary paths and values cannot safely use the
whole-resource transform. FHIRPath Patch and transaction-bundle PATCH are not
part of this operation.

`timeoutMs` must be positive and finite. A timeout throws `FhirSdkError` with
`code: 'timeout'`; a caller-aborted signal throws `code: 'cancelled'`. Both are
safe SDK errors and do not expose transport URLs, credentials, provider objects,
or response bodies. Request controls cannot alter authorization and do not add
an arbitrary root-path API. They are accepted by `metadata`, exact-profile and
family `read`, `search`, `next`, `create`/`createResource`, `update`, and
`delete`, plus client and family `batch`/`transaction`; omitting them preserves
the previous unbounded request behavior. Bulk submission and polling keep their
separate existing bulk controls rather than accepting a generic request escape
hatch.

With `createAidboxFhirClient`, timeout or cancellation rejects the caller's
promise but does not abort the underlying in-flight HTTP request. A mutation
may still be applied after that rejection. Re-read the resource to establish
the outcome before deciding what to do next; do not automatically retry the
mutation. The upstream Aidbox transport currently does not forward the abort
signal to its HTTP fetch. `createFetchTransport` forwards the signal, but a
client disconnect likewise cannot prove that the server did not apply a write.

`withDeidentification(policy, callback)` scopes one resource-level
de-identification policy across nested, batch, and multi-resource calls. The
callback receives the same profile-bound client. Writes and instance addresses
use one transformation context so references and `Bundle.entry.fullUrl` stay
consistent. The two ADR-009 policies are `development-pseudonymized` (structured
PII is transformed; the result remains pseudonymized personal data) and
`anonymous-export` (a technical no-relink transform whose in-memory secret and
mapping are destroyed in `finally` on success and failure). The policy name is
not a legal or DSGVO anonymization claim, does not authorize Zone-C or
third-party disclosure, and does not replace a purpose-specific
re-identification risk assessment.

```ts
import {
  anonymousExport,
  developmentPseudonymized,
} from '@cognovis/fhir-sdk/client'

await client.withDeidentification(developmentPseudonymized(), async (scoped) => {
  return scoped.forProfile(patientDescriptor).search({ _count: '20' })
})
```

Transform failures throw `CognovisDeidentificationError` (`code:
'deidentification'`). The producer engine result type is not part of this
public surface.

Column-level de-identification for tabular views, `$run`, `$sqlquery-run`, and
table materialization is a different seam from resource-level
`withDeidentification`. It is expressed on ViewDefinition columns through
`columnDeidentification` helpers and applies only to the SQL-on-FHIR path.
A de-identified ViewDefinition can be materialized only as a `table`. Keys
never appear in generated-SQL evidence, errors, receipts, or package
artifacts.

The normal read-model order is FHIR search/read with batch enrichment and lazy
detail loading, then live ViewDefinitions and `$sqlquery-run`, then a measured
immutable snapshot generation. Applications do not connect to Aidbox
PostgreSQL. `unsafe.rawSql` is isolated, requires the already-authorized
administrative grant, and is not the ordinary view or snapshot path.

```ts
await client.sqlOnFhir.viewDefinitions.create(view)
await client.sqlOnFhir.viewDefinitions.run({ viewReference: view.id, format: 'json', limit: 20 })
const sql = await client.sqlOnFhir.viewDefinitions.sql({ viewReference: view.id })
const table = await client.sqlOnFhir.viewDefinitions.materialize({ viewReference: view.id, type: 'table' })
await client.sqlOnFhir.sqlQueries.run({ libraryId: 'patient-count', format: 'fhir', parameters: { gender: 'female' } })
```

| SDK method | Aidbox operation |
| --- | --- |
| `sqlOnFhir.viewDefinitions.create` | `POST /fhir/ViewDefinition` — id optional |
| `sqlOnFhir.viewDefinitions.read` | `GET /fhir/ViewDefinition/{id}` — `null` on 404 |
| `sqlOnFhir.viewDefinitions.update` | `PUT /fhir/ViewDefinition/{id}` — id required |
| `sqlOnFhir.viewDefinitions.delete` | `DELETE /fhir/ViewDefinition/{id}` |
| `sqlOnFhir.viewDefinitions.run` | `POST /fhir/ViewDefinition/$run` (`viewReference`, `resource`, `group`, `_since`, `_limit`, `_format`; never `patient`). `Accept` follows `_format`: `application/json`, `application/x-ndjson`, `text/csv`. |
| `sqlOnFhir.viewDefinitions.sql` | `POST /fhir/ViewDefinition/$sql` — generated SQL evidence only |
| `sqlOnFhir.viewDefinitions.materialize` | `POST /fhir/ViewDefinition/$materialize` (`view`, `materialized-view`, `table`) |
| `sqlOnFhir.sqlQueries.create` | `POST /fhir/Library` — id optional |
| `sqlOnFhir.sqlQueries.read` | `GET /fhir/Library/{id}` — `null` on 404 |
| `sqlOnFhir.sqlQueries.update` | `PUT /fhir/Library/{id}` — id required |
| `sqlOnFhir.sqlQueries.delete` | `DELETE /fhir/Library/{id}` |
| `sqlOnFhir.sqlQueries.run` | `POST /fhir/Library/$sqlquery-run` or `POST /fhir/Library/{id}/$sqlquery-run`. `_format=fhir` requires Library `parameter` entries with `use: "out"`. A SQLQuery Library is a single read-only `SELECT` over unqualified declared `relatedArtifact` labels, not `unsafe.rawSql`. |
| `sqlOnFhir.snapshots.create` | Unique `POST /fhir/ViewDefinition` generation, `POST /fhir/ViewDefinition/$materialize` as `table`, then `POST /fhir/Library` bound to that generation |
| `sqlOnFhir.snapshots.read` | `POST /fhir/Library/{id}/$sqlquery-run` against the receipt's query Library |
| `bootstrap.ensureSearchIndexes` | idempotent GIN `jsonb_path_ops` on validated resource tables via administrative `POST /$sql` |
| `bootstrap.ensureViewIndexes` | structured `ViewIndexSpec` compiled from the ViewDefinition model via administrative `POST /$sql` |
| `unsafe.rawSql` | administrative `POST /$sql` |

`$materialize` replaces a same-named object and creates no indexes. It is not
atomic unless Aidbox proves otherwise. Live views stay current; snapshot
generations are uniquely named, immutable, and selected by an explicit
freshness or billing cut-off. Index bootstrap never slices `$sql` output.

Snapshot reuse is identity-checked, not name-checked. A receipt matches only
when `recipeViewCanonical`, ViewDefinition content digest, query Library
digest, `sourceWatermark`, admission kind (and query/plan when measured), and
the declared cut-off or freshness all agree. `selection.rebuildBeforeRun`
skips reuse and builds a new generation. `builtAt` is captured after
materialization and Library create. The bound query Library is part of the
receipt; changing its SQL is a different snapshot.

Bulk polling is bounded twice: 30 status requests and a 120-second deadline by
default. It waits 1 second before the second request, doubles the delay through
10 seconds, and accepts `bulkPolling` defaults on `createAidboxFhirClient` or
per-call overrides on `bulk.poll`. These controls change scheduling only; they
do not retry the non-idempotent submission.

Every submitted bulk input carries an `open()` function that streams the exact
immutable bytes associated with its URL. Aidbox 2607.1 expects gzip-compressed
NDJSON by default. The SDK detects gzip from those exact bytes, decompresses it
as a stream, then parses and profile-validates the NDJSON before it sends the
URL with `contentEncoding: "gzip"`; empty, malformed, wrong-type, or
profile-invalid sources fail without submission. The upstream Aidbox contract
also permits plain NDJSON, which is detected and submitted explicitly with
`contentEncoding: "plain"`; one run cannot mix encodings.

Preflight bounds each decoded NDJSON line to 1 MiB. Inputs containing a larger
line fail before provider submission.

This is an explicit trusted seam: the caller must ensure `open()` and the URL
expose the same immutable compressed object for the whole operation, normally
by using content-addressed storage or an upload receipt. The SDK never replaces
that stream with a second resource list. A mutable URL can change after
preflight, which the URL-only Aidbox `$import` primitive cannot
cryptographically prevent.

`bulk.batchValidateDiagnostic` must be granted separately by an Aidbox
`AccessPolicy` restricted to the intended actor, resource types, and controlled
environment. The SDK cannot create that authority and a boolean in application
configuration never substitutes for the store-side policy.

The Aidbox-backed `client.bootstrap.install` capability writes `AccessPolicy` at
the tenant root and `Subscription` below the configured FHIR base. Unless the
explicit real-store gates described under Development are supplied, these exact
routes are mock-backed contract evidence; they are not claims that a particular
Aidbox deployment accepted the fixtures.

### Errors

Every profile-bound client failure carries a stable ADR-009 discriminant such
as `transport`, `authorization`, `server`, `profile-validation`, or
`deidentification`. `CognovisDeidentificationError` is the only public
de-identification failure type. Branch on the code, not on message text:

```ts
try {
  await conditions.create(input)
} catch (error) {
  if ((error as { code?: string }).code === 'authorization') {
    // ...
  }
}
```

`FhirHttpError` is the advanced transport SPI's HTTP signal. `ResourceClient`
translates it at every operation boundary and retains its body only when that
body is a FHIR `OperationOutcome`; provider response objects, headers, timing,
request metadata, and bridge result envelopes never cross the public client
boundary. An `OperationOutcome` may contain patient data, so do not log
`FhirSdkError.outcome` raw.

## Dental builders

`@cognovis/fhir-sdk/dental`

Builders for the `de.cognovis.fhir.dental` guide: odontogram, periodontal and
peri-implant observations, gingival thickness and recession, dental findings,
conditions, periodontitis conditions, procedures, service requests and
communications, plus the shared FDI tooth and surface helpers and the dental
extension URLs.

```ts
import { buildOdontogramObservation } from '@cognovis/fhir-sdk/dental'

const observation = buildOdontogramObservation({
  subject: { reference: 'Patient/p-1' },
  status: 'final',
  toothNumber: '16',
  effectiveDateTime: '2026-08-25T09:00:00Z',
  toothPresence: { value: { system: 'http://snomed.info/sct', code: '278661005' } },
})
```

Each builder returns a plain FHIR resource with `meta.profile` set, typed by the
generated profile classes.

## Dental Core profile classes

`@cognovis/fhir-sdk/dental-core`

Applications import Dental Core profile and extension classes only from this
subpath. It re-exports every generated class of the pinned
`de.cognovis.fhir.dental.core` package, plus the package identity and canonical
URLs already published under `@cognovis/fhir-sdk/canonicals`. Consumers do not
depend on `@cognovis/fhir-release` or on its projection layout.

```ts
import {
  DentalChartStateProfile,
  DentalTargetChartStateProfile,
  DentalToothStateProfile,
  RecordedRootFractureExtProfile,
} from '@cognovis/fhir-sdk/dental-core'

const resource = DentalToothStateProfile.createResource({
  subject: { reference: 'Patient/example' },
  bodySite: { text: '16' },
  component: [],
  status: 'final',
})
const observation = DentalToothStateProfile.apply(resource).toResource()
```

The surface is generated from the installed release closure by
`scripts/generate-release-profile-registry.ts`. A projection bump regenerates
it; `bun run check:release-profiles` fails when a class is missing or extra.

## Terminology and canonical URLs

`@cognovis/fhir-sdk/terminology` and `@cognovis/fhir-sdk/canonicals`

Both surfaces are generated from the installed release closure by
`scripts/generate-terminology.ts` and are stamped with the release version and
the closure digest they came from:

```sh
bun run generate:terminology   # regenerate
bun run check:terminology      # fail if the committed output is stale
```

- `terminology` exports the system URL constants of the estate guides, the codes
  those guides fix (`DENTAL_CODES`, `PRAXIS_CODES`, ...), the displays they
  define (`DENTAL_DISPLAYS`, ...), the German base system URLs the profiles
  reference (`referenced-systems`), and the provenance constants
  `RELEASE_VERSION` and `RELEASE_CLOSURE_DIGEST`.
- `canonicals` exports one module per estate Implementation Guide with its
  profile and extension canonical URLs, so applications stop hand-maintaining
  URL literals.

### Resolving KBV displays

This package deliberately ships no KBV display constants and no KBV concept
lists, and the same holds for SNOMED CT, LOINC, the BfArM terminologies and the
billing catalogues. Only URLs, and codes the Cognovis guides author themselves,
are generated.

Displays are resolved store-side. The bootstrap installs `kbv.all.st-combined`
and the other closure packages into your FHIR server, so the server holds those
CodeSystems under their original licences and answers:

```ts
// $lookup against the server that holds the CodeSystem
const outcome = await transport.request('GET', '/CodeSystem/$lookup', {
  query: { system: 'https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_KBV_DMP', code: '01' },
})
```

A plain `CodeSystem` read works the same way. This keeps licensed terminology in
exactly one place — the store — instead of copying it into every consumer.

## Bootstrap

`@cognovis/fhir-sdk/bootstrap`

This subpath installs the release package closure into an arbitrary standard
FHIR server with plain FHIR interactions only: conformance resources are
written with `PUT /<type>/<id>`, or `POST /<type>` when they carry no id.

It does not install Aidbox-native runtime resources. For the two Aidbox runtime
resources owned by ADR-009, an ordinary authenticated client instead exposes
the intent-specific `client.bootstrap.install(resource)` call.
It accepts only identified `AccessPolicy` and `Subscription` resources and
translates authorization, server, and transport failures to `FhirSdkError`.
`AccessPolicy` is written at the Aidbox tenant root, while `Subscription` is a
FHIR resource written below the configured FHIR base. The credential still
needs the corresponding store-side administrative grant. Store-side
`AccessPolicy` is the authority boundary for this controlled-environment
operation; no SDK option can elevate the caller.

```ts
import { bootstrapStore, loadInstalledManifest } from '@cognovis/fhir-sdk/bootstrap'

const result = await bootstrapStore({
  transport,
  closure: loadInstalledManifest().closure,
  cognovisRegistryHeaders: { Authorization: `Bearer ${registryToken}` },
})
// result.packages: installed | skipped (+ reason) | failed (+ error)
```

Routing follows the `origin` of each closure entry:

| Origin | Behaviour |
| --- | --- |
| `private` | Fetched from `https://npm.cognovis.de` (token required). |
| `public` | Fetched from `packages.fhir.org`, falling back to `packages2.fhir.org` and `packages.simplifier.net`. Never proxied through Cognovis infrastructure. |
| `zts` | Skipped with a recorded reason. Licensed terminology bytes are never mirrored, bundled or redistributed by this SDK; the operator loads them from the terminology service. |
| lock snapshot | Skipped: no registry serves those bytes. |

Verification is not optional. Every tarball is checked against the SHA-256
digest the release manifest pins: a mismatch aborts that package with
`BootstrapDigestMismatchError`, and an entry that carries no digest at all is
refused with `BootstrapUnverifiableError` before anything is downloaded.

`cognovisRegistryHeaders` travels to the Cognovis registry and to nothing else.
Public FHIR registries are third-party hosts, so a custom `fetchTarball` also
receives an empty header set for those URLs; `headersForUrl` is exported so the
rule can be asserted independently. A credentialed request is additionally sent
with `redirect: 'manual'` and its response origin is checked, so a redirect
cannot decide at runtime which host receives the token — the header name is
yours to choose, and no runtime-level stripping rule can be assumed for it.

The registry token is the same value as the `_authToken` in your `.npmrc`, sent
as `Authorization: Bearer <token>`, which is what the Cognovis registry expects.

Two limits bound what a hostile or broken registry can do, both stated in code
as `MAX_TARBALL_BYTES` and `MAX_UNCOMPRESSED_BYTES`:

| Limit | Value | Largest package in the closure |
| --- | --- | --- |
| Download | 64 MiB, enforced on `Content-Length` and while streaming | `hl7.fhir.r4.core@4.0.1`, 12.8 MB |
| Decompression | 256 MiB `maxOutputLength` | the same package, 49 MB expanded |

The download ceiling is enforced *before* the digest is computed, because the
digest gate only protects bytes that have already been read.

Archive content is treated as untrusted after the digest gate as well: a digest
attests identity, not benignity. Tar headers are checksum-verified and their
size fields bounded, and a resource whose `id` or `resourceType` is not a valid
FHIR identifier is refused with `BootstrapUnsafeResourceError` rather than
interpolated into a request path. Resources under an `example/` directory of a
package are not installed. `ImplementationGuide` resources are not
installed — they are packaging metadata whose references point at guide
examples, which servers enforcing referential integrity reject.

## Migrating from a predecessor package

Consumers coming from the package this SDK was extracted from find the rename
table, the behavioural changes and the module moves in
[MIGRATION.md](MIGRATION.md), which is part of the repository rather than of the
published tarball.

## Development

```sh
bun install
bun run typecheck
bun run build            # dist/ with declarations
bun run test             # unit tests + the package-surface policy test
bun run check:terminology
bun run test:integ       # needs a FHIR server, see below
```

The standard-store integration uses `FHIR_SDK_INTEG=1` and
`FHIR_SDK_INTEG_BASE_URL`. A separate real-Aidbox factory probe is gated by
`FHIR_SDK_AIDBOX_INTEG=1` plus `FHIR_SDK_AIDBOX_BASE_URL`,
`FHIR_SDK_AIDBOX_CLIENT_ID`, and `FHIR_SDK_AIDBOX_CLIENT_SECRET`; its fixture
must contain at least two Patients so a one-item search produces a continuation.
An AccessPolicy write is excluded from that ordinary probe. It runs only when
`FHIR_SDK_AIDBOX_ADMIN_INTEG=1`, `FHIR_SDK_AIDBOX_BASE_URL`, dedicated
`FHIR_SDK_AIDBOX_ADMIN_CLIENT_ID`/`FHIR_SDK_AIDBOX_ADMIN_CLIENT_SECRET`
credentials, and an operator-reviewed identified AccessPolicy in
`FHIR_SDK_AIDBOX_ACCESS_POLICY_JSON` are all supplied. The test never invents a
permissive policy or logs the payload or credentials. Without these explicit
inputs, real-store AccessPolicy installation remains unexecuted and the route
contract is covered by prefix-aware mocks.

SQL-on-FHIR live cases live in `src/__tests__/sql-on-fhir.integ.test.ts` and
use the same `FHIR_SDK_AIDBOX_INTEG=1` ordinary credentials. Administrative
index creation and `EXPLAIN` require `FHIR_SDK_AIDBOX_ADMIN_INTEG=1` plus the
dedicated admin credentials.

The optional real-Aidbox bulk probe additionally requires
`FHIR_SDK_AIDBOX_BULK_INTEG=1`, `FHIR_SDK_AIDBOX_BULK_INPUT_URL`, and
`FHIR_SDK_AIDBOX_BULK_SOURCE_FILE`. The URL must expose an immutable gzip
Patient NDJSON object, and the source file must be that exact `.ndjson.gz`
object, not its decompressed form. The SDK streams those gzip bytes through its
preflight validation and Aidbox fetches the identical object. The local
integration harness enables insecure HTTP only when
`FHIR_SDK_AIDBOX_BASE_URL` resolves to loopback; all other targets retain the
bridge's HTTPS requirement.

The package-surface policy test scans what `npm pack` would publish and fails
when it finds traces of the platform this SDK was extracted from, anonymization
or PII symbols, third-party concept content, or dependency drift. Run
`bun run build` before the suite; the test fails loudly when `dist/` is missing
rather than passing vacuously. `prepack` rebuilds automatically, so a publish
cannot ship a `dist/` that no longer matches `src/`.

The entry-point test asserts that the root export and the subpath exports
resolve to one build of each module. They must: `ResourceClient` decides whether
a 404 is absence or an error with `instanceof`, and a second copy of
`FhirHttpError` would silently break the documented 404 contract.

Integration tests run against a vanilla HAPI FHIR JPA server:

```sh
docker run --rm -p 8080:8080 hapiproject/hapi:v8.10.0-3
FHIR_SDK_INTEG_BASE_URL=http://localhost:8080/fhir bun run test:integ
```

### Workforce transactions

Use one ordinary client per verified workforce request. The SDK does not verify
application roles or exchange the credential. It sends that credential only to
the configured Aidbox base, refuses redirects, and never falls back to a machine
account. The factory accepts exactly one of `bearerToken`,
`basicAuth: { username, password }`, or `clientId` plus `clientSecret`. HTTP needs
explicit `allowInsecureRequests: true` for local testing.

```ts
const client = await createAidboxFhirClient({ baseUrl, bearerToken: verifiedToken })
const result = await client.forResourceType('Condition').transaction([
  { method: 'GET', resourceType: 'Condition', id: conditionId },
  { method: 'PUT', resource: correctedCondition, ifMatch: previousEtag },
  { method: 'PUT', descriptor: provenanceDescriptor, resource: provenance, ifNoneMatch: '*', fullUrl: provenanceUrn },
], { signal, timeoutMs: 5000 })

const { resource, response } = result.entry[0]!
// response.status, response.location, response.etag, response.lastModified,
// and response.outcome retain the server's ordered FHIR response evidence.
```

`POST` and `PUT` accept a resource. `GET` and `DELETE` accept an id and a
resource type on the family API, or an id and descriptor on `client.transaction`.
Migrate old DELETE entries from `{ resource, method: 'DELETE' }` to
`{ descriptor, id, method: 'DELETE' }` or `{ resourceType, id, method: 'DELETE' }`.
Both composite APIs preserve `ifMatch`, `ifNoneMatch`, and `fullUrl`. Family
transactions can contain different resource types and mix inferred entries with
explicit descriptor entries. A `provenanceDescriptor` created with `defineProfile`
can bind a generic audit resource while the clinical entries retain their declared
leaf profiles. A descriptor-less GET result must resolve to a release profile;
an explicit GET result must satisfy its supplied descriptor. Conditional GET may return 304 without a
resource. The SDK returns raw validated resources in composite results.
In a family batch, failure to resolve a descriptor-less input profile rejects
the whole call before dispatch. An explicit descriptor validation failure is
returned as a per-entry batch failure; valid sibling entries still run.
Successful batch writes can omit `resource`; an OperationOutcome returned by a
write is retained in `response.outcome`, never exposed as the selected profile's
resource. Batch GET still requires a profile resource unless the status is 304.

A transaction uses one atomic server request. `FhirTransactionFailedError`
retains HTTP `status`, `outcome`, and complete server entries when supplied, or
submitted entries when the server provides only an OperationOutcome. Evidence
can contain patient data and must not be logged raw. The SDK never retries a
failed transaction as individual writes. A successful commit followed by invalid
response evidence raises a validation error; callers must reconcile state before
retrying.

Inside `withDeidentification`, the complete bundle is transformed together so
fullUrl references and Provenance targets remain consistent. An id-less create
with a fullUrl receives a temporary identity for that graph transform; its
generated id is removed before dispatch while the transformed fullUrl and sibling
references remain. Every transformed resource is revalidated. Request conditions
remain unchanged. Deidentification guard errors reject both batch and transaction
calls before dispatch.

SQLQuery validation parses PostgreSQL structure with the pinned
`pgsql-ast-parser` dependency. Nonrecursive CTEs, derived SELECTs, joins,
UNION/UNION ALL, scalar subqueries, EXISTS, DISTINCT ON, aggregate FILTER and
supported window expressions may read only declared ViewDefinition labels.
CTE names are visible within their lexical scope; a derived alias never grants
access to another relation. Nested writes, schema-qualified base tables,
locking clauses and prohibited functions fail before dispatch. Recursive CTEs,
MATERIALIZED CTE modifiers, table functions and other unsupported parser syntax
also fail closed.

Named placeholders are checked outside quoted text and comments, including
PostgreSQL casts. Parsing uses a temporary normalized copy; the original SQL
and parameter binding reach Aidbox unchanged. FHIR output checks the outer
SELECT projection, so CTE-local aliases need not match the declared result
columns.

### Named terminology and Encounter change operations

The same authenticated client owns these fixed operations. Canonical `url` and
`system` values are operation parameters, never HTTP destinations.

```ts
const concept = await client.terminology.lookup({
  system: codeSystemUrl,
  code,
  version: installedVersion,
  property: ['parent', 'child', 'inactive'],
}, { signal, timeoutMs: 5000 })
const expanded = await client.terminology.expand({ url: valueSetUrl, filter, count: 100 })
const validation = await client.terminology.validateCode({ url: valueSetUrl, system, code })
const translation = await client.terminology.translate({ url: conceptMapUrl, system, code })
const changes = await client.encounterChanges({ version: persistedVersion, count: 5000 })
```

Terminology results retain Parameters names, repeated properties, Coding values,
translation equivalence and nested ValueSet expansion concepts. Public result
fields derive from the pinned release's core Parameters and ValueSet types;
operation-specific validators check their shapes without resolving a resource
profile. Unsupported Parameters value choices fail closed. Lookup and translate
send POST Parameters; expand and validate-code use GET query parameters.
HTTP errors retain `FhirSdkError.status` and `.outcome`, including 404 for missing
codes and OperationOutcome details. HTTP 401/403 use the `authorization`
discriminant; other rejected responses use `server`. No operation changes
credentials on failure. Translation match concept and equivalence are optional
R4 fields, validated when present; unmatched evidence may omit the concept.

`encounterChanges` calls the fixed root `/Encounter/$changes` endpoint. It uses a
numeric version when supplied, always sets `omit-resources=true`, and
bounds `_count` to 1–5000, default 5000. The result includes `version`,
`upsertIds`, `deleteIds`, and ordered created/updated/deleted change identities.
Each change resource contains only `resourceType` and `id`, even if the server
returns additional resource fields.
An initial request without a version accepts a cursor-only response and returns
that version with empty change lists and `notModified: false`. Responses to
versioned requests must contain a `changes` array.
HTTP 304 returns `notModified: true`, empty changes and the caller's original
version. Invalid or decreasing versions, and changes without an advancing
version, fail before any caller cursor is changed.
This feed is unavailable inside a deidentification scope because its cursor names
an identifying source stream. Every named operation accepts `RequestOptions`.
`timeoutMs` bounds the caller's wait and `signal` supports cancellation; failures
use the distinct `timeout` and `cancelled` SDK discriminants. Late responses do
not become successful results after either control has fired.

Terminology methods obtained inside `withDeidentification` remain bound to that
scope's lifetime. After the callback ends, retained clients and detached methods
fail with `deidentification` before authenticated dispatch.

The live atomicity proof extends `src/__tests__/round-trip.integ.test.ts` and is
inert by default. Run it only against an isolated Reetfurt loopback endpoint,
with `FHIR_SDK_REETFURT_ATOMIC_INTEG=1` and an explicit
`FHIR_SDK_ATOMIC_BASE_URL`. It never falls back to the shared integration URL.
Supply exactly one existing credential alternative through
`FHIR_SDK_AIDBOX_BEARER_TOKEN`, `FHIR_SDK_AIDBOX_BASIC_USERNAME` plus
`FHIR_SDK_AIDBOX_BASIC_PASSWORD`, or `FHIR_SDK_AIDBOX_CLIENT_ID` plus
`FHIR_SDK_AIDBOX_CLIENT_SECRET`.

```sh
bun test src/__tests__/round-trip.integ.test.ts --test-name-pattern 'isolated Reetfurt conditional transactions'
```

The proof records transactional GET/ETag evidence and checks that stale-version
and create-only failures leave Patient and Provenance unchanged, with no new
audit resource. It retains two generated synthetic resources for inspection,
marked with a unique `urn:cognovis:fhir-sdk:isolated-atomic-proof:<uuid>` source.
It performs no cleanup or deletion.

Searches can opt into resource-type continuation confinement and cycle rejection:

```ts
const page = await organizations.search({ active: 'true' }, {
  continuationPolicy: { path: 'resource-type', rejectCycles: true },
})
if (page.next) await organizations.next(page.next)
```

Both exact-profile and resource-family clients support this search-only option.
The SDK snapshots it before dispatch and carries it in opaque continuation tokens.
Next targets must resolve to the exact searched resource-type path within the
configured origin and FHIR base; instance, operation, root and trailing-slash
paths are rejected before HTTP dispatch. Default searches retain same-base HAPI
root-query paging support.

Cycle identity uses the resolved pathname and serialized query, ignoring fragments
without sorting or decoding query parameters. Only successfully consumed next
requests enter the descendant token's history; the initial search is excluded.
Retrying the same token, even after success, is permitted. Independent searches
and branches do not share history, and failed requests or page validation do not
consume a target. Callers retain responsibility for page-count limits.
